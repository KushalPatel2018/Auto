﻿#------------------------------------------------------------------------------------------
#Read software names from CSV file and get the UninstallString and QuietUninstallString
#Parse the UninstallString and QuitUninstallString values and get the MsiExec and Exe path
#Execute the MsiExec package removel step and trigger uninstall.exe along with argument list
#./Scriptname.ps1
#------------------------------------------------------------------------------------------
$MyDir = "C:\Temp\Standard Reclaimer\Final_CSV"$softwarelistcsv = "$MyDir\software.csv"$LogFile = "$MyDir\log.txt"
$32bitpath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*"$64bitpath = "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*"#---------------------------------------------------------------#Function caputre the log information and place into log file#---------------------------------------------------------------function Write_log{    Param ([string]$LogString)    $LogMessage = "$LogString"    Add-content $LogFile -value $LogMessage
}#---------------------------------------------------------------#Function used to return the data and time for loging purpose#---------------------------------------------------------------function dt {    echo $(get-date -Format 'dd-MM-yyyy hh:mm:ss tt')}
#---------------------------------------------------------------#Function Get all the apllication list from computer#---------------------------------------------------------------
function Uninstall-Applications($32bitpath, $64bitpath)
{    $installed64 = Get-ItemProperty "$32bitpath" | Where-Object { $_.DisplayName -ne $null } | Select-Object DisplayName, DisplayVersion, UninstallString, QuietUninstallString    
    if ($installed64 -ne '')
    {
        $installed32 = Get-ItemProperty "$64bitpath" | Where-Object { $_.DisplayName -ne $null } | Select-Object DisplayName, DisplayVersion, UninstallString, QuietUninstallString
        $installed = $installed32
    }   
    $installed = $installed64    
    $installed | Select-Object DisplayName, DisplayVersion, UninstallString, QuietUninstallString    }#---------------------------------------------------------------#Function Uninstall MSI Packages#---------------------------------------------------------------function Uninstall-MSIpackage($UninstallPath){    $uninstallString = $UninstallPath -Replace "msiexec.exe","" -Replace "/I","" -Replace "/X",""    $uninstallString = $uninstallString.Trim()        Write_log "$(dt) - Unisntall string - $uninstallString" 
    Write_log "$(dt) - $softwarename - Uninstalling..."
    try        {
        Start-Process -Wait -FilePath MsiExec.exe -Argumentlist "/X $uninstallString /quiet /norestart" 
    }
    catch
    {
        Write_log "$(dt) - $($_.Exception)"
        Write_log "$(dt) - $($softwarename) - $($uninstallString) -  Uninstallation failed, please check manually"                                    
    }
}

#---------------------------------------------------------------
#Functoon Uninstall exe packages
#---------------------------------------------------------------

function Uninstall-EXE($UninstallPath)
{
        
    $isExeOnly = Test-Path -LiteralPath "$($UninstallPath)"
    if ($isExeOnly) { $UninstallPath = "`"$UninstallPath`"" }     
    
    # Split the command line into argument list.            
    if ($UninstallPath[0] -eq '"') {
        $unused, $exe, $argList = $UninstallPath -split '"', 3
    }
    else 
    {
        $exe, $argList = $UninstallPath -split ' ', 2
    }
    
    write_log "$(dt) - -FilePath $exe -ArgumentList $argList -Verb runas -Wait -PassThru"
    Write_log "$(dt) - $softwarename - Uninstalling..."

    try
    {
    
        #Check any default arugument list exist
        if ($argList -ne '')
        {
            try
            {
                Start-Process -FilePath "$exe" -ArgumentList $argList -Verb runas -Wait -PassThru 
            }
            catch    
            {
                Write_log "$(dt) - $($_.Exception)"
                Write_log "$(dt) - $($softwarename) - $($uninstallString) -  Uninstallation failed, please check manually"                                    
            }

            #Unstallation failed when used default argument list
            if ($res.ExitCode -ne 0)
            {
                try
                {
                    Start-Process -FilePath "$exe" -ArgumentList '/quiet /qn /S /norestart /silent' -Verb runas -Wait -PassThru 
                }
                catch    
                {
                    Write_log "$(dt) - $($_.Exception)"
                    Write_log "$(dt) - $($softwarename) - $($uninstallString) -  Uninstallation failed, please check manually"                                    
                }
            }
        }
        else
        {

            #When default argument list failed script passing necessary prameter and try to uninstall the exe
            try
            {
                Start-Process -FilePath "$exe" -ArgumentList '/quiet /qn /S /norestart /silent' -Verb runas -Wait -PassThru 
            }
            catch    
            {
                Write_log "$(dt) - $($_.Exception)"
                Write_log "$(dt) - $($softwarename) - $($uninstallString) -  Uninstallation failed, please check manually"                                    
            }

        }


    }
    catch    
    {
        Write_log "$(dt) - $($_.Exception)"
        Write_log "$(dt) - $($softwarename) - $($uninstallString) -  Uninstallation failed, please check manually"                                    
    }
}

#---------------------------------------------------------------
#Get all softwares UninstallString, QuietUninstallString values 
#---------------------------------------------------------------

$csvsoftwares = Import-CSV -Path $softwarelistcsv | Select-Object -ExpandProperty Software_Name
$quietuninstallapp =  Uninstall-Applications $32bitpath $64bitpath
#Get each software from csv and check against the main list from registry and perform the uninstallation steps
$csvsoftwares | ForEach-Object {

    #$quietuninstallstring=''
    $softwarename = $_
    
    #($quietuninstallapp | Where-Object { $softwarename -contains $_.DisplayName} | Measure-Object).Count 

    if (($quietuninstallapp | Where-Object { $softwarename -contains $_.DisplayName} | Measure-Object).Count -ge 1)
    {
                
        Write_log "$(dt) - App (from csv) - $softwarename installed, proceding further step"
            
                $cursoft = $quietuninstallapp | Where-Object { $softwarename -contains $_.DisplayName}                            
            
                $softwarename = $cursoft.DisplayName
                $softwareversion = $cursoft.DisplayVersion    
                $quietuninstallstring = $cursoft.QuietUninstallString
                $uninstallstring = $cursoft.UninstallString                   
                $quietuninstallstring
                   
                Write_log "$(dt) - Processing software - $($softwarename)"                
                Write_log "$(dt) - QuietUninstallString - $($quietuninstallstring)"
                Write_log "$(dt) - UninstallString - $($uninstallstring)"


                if (($uninstallstring.Length -eq 0) -and ($quietuninstallstring.Length -eq 0))
                {
                    Write_log "$(dt) - $($softwarename) - not able to get both Uninstall and Quiet Uninstall string"                    
                }             
                                    
                #Check QuietUninstallString  value exist, if yes then follow the QuietUninstallString string value
                #If QuietUninstallString not exist then script will use UninstallString value
                $UninstallPath = $quietuninstallstring

                $uninstallflag = 0
                   
                if ($UninstallPath.length -ne 0)
                {

                    #if UninstallString value has MsiExec else Uninstall EXE
                    if ($UninstallPath -like "*MsiExec.exe*")
                    {
        
                        Write_log "$(dt) - Calling MSI Package remover function (path from UninstallString) - $($UninstallPath)"
                        Uninstall-MSIpackage $UninstallPath
    
                    }
                    else
                    {
            
                        Write_log "$(dt) - Calling EXE remover function (path from UninstallString) - $($UninstallPath)"    

                        Uninstall-EXE "$UninstallPath"
                
                    }

                    $uninstallflag = 1

                }     
                
                #--------------------------------------------------------------------
                #When QuietUninstallString value empty then getting UninstallString
                #--------------------------------------------------------------------

                if ($uninstallflag -eq 0)
                {

                    $UninstallPath = $uninstallstring

                    if($UninstallPath.Length -ne 0)
                    {               
                    
                        #if UninstallString value has MsiExec else Uninstall EXE
                        if ($UninstallPath -like "*MsiExec.exe*")
                        {
        
                            Write_log "$(dt) - Calling MSI Package remover function (path QuietUninstallString) - $($UninstallPath)"
                            Uninstall-MSIpackage $UninstallPath
    
                        }
                        else
                        {
            
                            Write_log "$(dt) - Calling EXE remover function (path from QuietUninstallString) - $($UninstallPath)"    
                        
                            Uninstall-EXE "$UninstallPath"
                
                        }
                    }                    
                }
        Write_log "$(dt) - ---------------------------------------------------------------------"

    }
    else
    {
        Write_log "$(dt) - App (from csv) - $softwarename not installed"

        Write_log "$(dt) - ---------------------------------------------------------------------"
    }    
}